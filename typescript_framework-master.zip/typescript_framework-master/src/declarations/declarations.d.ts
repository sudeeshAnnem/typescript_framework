// declare module 'express-oas-generator';
declare module 'cors';