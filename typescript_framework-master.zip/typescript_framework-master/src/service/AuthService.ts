import { BaseService } from "./BaseService";

export class AuthService implements BaseService {
    
}